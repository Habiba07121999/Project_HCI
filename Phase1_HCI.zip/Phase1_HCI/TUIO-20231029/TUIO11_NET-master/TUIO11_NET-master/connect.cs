﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;
using System.ComponentModel;

using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace TuioDemo
{
    public class Connect
    {
        int byteCount;
        NetworkStream stream;
        byte[] sendData;
        TcpClient tcpClient;
        public bool connectToSocket(String host, int portNumber)
        {
            try { 
                           tcpClient = new TcpClient(host, portNumber);
                MessageBox.Show("Connection Made ! with " + host);
                return true;
            }
            catch (SocketException e)
            {
                MessageBox.Show("Connection Failed: " + e);
                return false;
            }
        }
        public bool sendMessage(String msg)
        {
            try
            {
                byteCount = Encoding.UTF8.GetByteCount(msg);
                sendData = new byte[byteCount];
                sendData = Encoding.UTF8.GetBytes(msg);
                stream = tcpClient.GetStream();
                stream.Write(sendData, 0, sendData.Length);
                MessageBox.Show("Data sent" + msg);
                return true;
            }
            catch (System.NullReferenceException e)
            {
                return false;
            }
        }
        string[] last;
        int i;
        string[] xy;
        public string recieveMessage()
        {
            try
            {
                stream = tcpClient.GetStream();
                byte[] receiveBuffer = new byte[1024];
                int bytesReceived = stream.Read(receiveBuffer, 0, receiveBuffer.Length);
                string data = Encoding.UTF8.GetString(receiveBuffer, 0, receiveBuffer.Length);
                return data;
            }
            catch (Exception e)
            {
                return null;
            }
        }
        public bool closeConnection()
        {
            if (stream != null)
            {
                stream.Close();
            }

            if (tcpClient != null)
            {
                tcpClient.Close();
            }

            return true;
        }
    }
}