﻿/*
	TUIO C# Demo - part of the reacTIVision project
	Copyright (c) 2005-2016 Martin Kaltenbrunner <martin@tuio.org>

	This program is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; either version 2 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

using System;
using System.Drawing;
using System.Windows.Forms;
using System.ComponentModel;
using System.Collections.Generic;
using System.Windows.Media;
using System.Collections;
using System.Threading;
using System.Media;
using System.Windows.Media;
using TUIO;
using Timer = System.Windows.Forms.Timer;
using System.IO;
using System.Net.NetworkInformation;
using System.Runtime.Remoting.Contexts;
using System.Runtime.ConstrainedExecution;

namespace TuioDemo
{
    public class TuioDemo : Form, TuioListener
    {
        private TuioClient client;
        private Dictionary<long, TuioObject> objectList;
        private Dictionary<long, TuioCursor> cursorList;
        private Dictionary<long, TuioBlob> blobList;

        public static int width, height;
        private int window_width = 2000;
        private int window_height = 2000;
        

        private int window_left = 0;
        private int window_top = 0;
        private int screen_width = Screen.PrimaryScreen.Bounds.Width;
        private int screen_height = Screen.PrimaryScreen.Bounds.Height;

        int flag_ID;
        int flag_ID2;
        int flag_arrive1 = 0;
        int flag_arrive2 = 0;
        int flag_arrive3 = 0;
        int flag_arrive4 = 0;
        int flag_arrive5 = 0;
        Bitmap off;
        int x, y;

        private bool fullscreen;
        private bool verbose;

        Font font = new Font("Arial", 10.0f);
        SolidBrush fntBrush = new SolidBrush(System.Drawing.Color.White);
        //SolidBrush bgrBrush = new SolidBrush(System.Drawing.Color.WhiteSmoke);
        SolidBrush bgrBrush = new SolidBrush(System.Drawing.Color.Green);
        SolidBrush curBrush = new SolidBrush(System.Drawing.Color.FromArgb(192, 0, 192));
        SolidBrush objBrush = new SolidBrush(System.Drawing.Color.FromArgb(64, 0, 0));
        SolidBrush blbBrush = new SolidBrush(System.Drawing.Color.FromArgb(64, 64, 64));
        System.Drawing.Pen curPen = new System.Drawing.Pen(new SolidBrush(System.Drawing.Color.White), 1);

        int x_lionhouse, y_lionhouse;
        int x_birdhouse, y_birdhouse;
        int x_rabbithouse, y_rabbithouse;
        int x_doghouse, y_doghouse;
        int x_monkeyhouse, y_monkeyhouse;
        Connect c = new Connect();
        int flagrastart = 0;
        Timer tt = new Timer();
        private Bitmap img_lionhouse;
        private Bitmap img_birdhouse;
        private Bitmap img_rabbithouse;
        private Bitmap img_doghouse;
        private Bitmap img_monkeyhouse;
        private Bitmap img;
        bool messageBoxShownlion = false;
        bool messageBoxShownMonkey = false;
        bool messageBoxShownRabbit = false;
        bool messageBoxShownBird = false;
        bool messageBoxShownDog = false;

        public TuioDemo(int port)
        {
            tt.Tick += Tt_Tick;
            this.Load += TuioDemo_Load;
            this.Paint += TuioDemo_Paint;
            this.WindowState = FormWindowState.Maximized;
            
            tt.Start();
            verbose = false;
            fullscreen = false;
            width = window_width;
            height = window_height;
           
            ClientSize = new Size(width, height);
            Name = "TuioDemo";
            Text = "TuioDemo";

            Closing += new CancelEventHandler(Form_Closing);
            KeyDown += new KeyEventHandler(Form_KeyDown);

            SetStyle(ControlStyles.AllPaintingInWmPaint |
                            ControlStyles.UserPaint |
                            ControlStyles.DoubleBuffer, true);

            objectList = new Dictionary<long, TuioObject>(128);
            cursorList = new Dictionary<long, TuioCursor>(128);
            blobList = new Dictionary<long, TuioBlob>(128);

            client = new TuioClient(port);
            client.addTuioListener(this);
            client.connect();
           
          
        }

        private void TuioDemo_Paint(object sender, PaintEventArgs e)
        {
            DrawDubb(this.CreateGraphics());
            //DrawScene(CreateGraphics());
        }

        //Bitmap img_cage;
        Graphics g;
        private void TuioDemo_Load(object sender, EventArgs e)
        {
            
            g = this.CreateGraphics();
            off = new Bitmap(ClientSize.Width, ClientSize.Height);
            c.connectToSocket("127.0.0.1", 5009);
            //this.WindowState = FormWindowState.Maximized;

            x_lionhouse = 50;
            y_lionhouse = 400;
            img_lionhouse = new Bitmap("lionhouse.bmp");
            img_lionhouse.MakeTransparent(System.Drawing.Color.White);
            img_lionhouse.MakeTransparent(img_lionhouse.GetPixel(0, 0));


            
            x_monkeyhouse = 400;
            y_monkeyhouse = 50;
            img_monkeyhouse = new Bitmap("monkeyhouse.bmp");
            img_monkeyhouse.MakeTransparent(System.Drawing.Color.White);
            img_monkeyhouse.MakeTransparent(img_monkeyhouse.GetPixel(0, 0));
            

            x_birdhouse = 700;
            y_birdhouse = 600;
            img_birdhouse = new Bitmap("birdhouse.bmp");
            img_birdhouse.MakeTransparent(System.Drawing.Color.White);
            img_birdhouse.MakeTransparent(img_birdhouse.GetPixel(0, 0));
            //DrawDubb(CreateGraphics());

            x_rabbithouse = 1300;
            y_rabbithouse = 400;
            img_rabbithouse = new Bitmap("rabbithouse.bmp");
            img_rabbithouse.MakeTransparent(System.Drawing.Color.White);
            img_rabbithouse.MakeTransparent(img_rabbithouse.GetPixel(0, 0));

            x_doghouse = 1000;
            y_doghouse = 50;
            img_doghouse = new Bitmap("dog house.bmp");
            img_doghouse.MakeTransparent(System.Drawing.Color.White);
            img_doghouse.MakeTransparent(img_doghouse.GetPixel(0, 0));
            

            DrawDubb(CreateGraphics());
        }

        private void Tt_Tick(object sender, EventArgs e)
        {
            //tt.Stop();
            DrawDubb(this.CreateGraphics());
            //DrawScene(CreateGraphics());
        }

        private void Form_KeyDown(object sender, KeyEventArgs e)
        {

            if (e.KeyData == Keys.F1)
            {
                if (fullscreen == false)
                {

                    width = screen_width;
                    height = screen_height;

                    window_left = Left;
                    window_top = Top;

                    FormBorderStyle = FormBorderStyle.None;
                    Left = 0;
                    Top = 0;
                    Width = screen_width;
                    Height = screen_height;

                    fullscreen = true;
                }
                else
                {

                    width = window_width;
                    height = window_height;

                    FormBorderStyle = FormBorderStyle.Sizable;
                    Left = window_left;
                    Top = window_top;
                    Width = window_width;
                    Height = window_height;

                    fullscreen = false;
                }
            }
            else if (e.KeyData == Keys.Escape)
            {
                Close();

            }
            else if (e.KeyData == Keys.V)
            {
                verbose = !verbose;
            }

        }

        private void Form_Closing(object sender, CancelEventArgs e)
        {
            client.removeTuioListener(this);

            client.disconnect();
            Environment.Exit(0);
        }

        public void addTuioObject(TuioObject o)
        {
            lock (objectList)
            {
                objectList.Add(o.SessionID, o);
            }
            if (verbose) Console.WriteLine("add obj " + o.SymbolID + " (" + o.SessionID + ") " + o.X + " " + o.Y + " " + o.Angle);
        }

        public void updateTuioObject(TuioObject o)
        {

            if (verbose) Console.WriteLine("set obj " + o.SymbolID + " " + o.SessionID + " " + o.X + " " + o.Y + " " + o.Angle + " " + o.MotionSpeed + " " + o.RotationSpeed + " " + o.MotionAccel + " " + o.RotationAccel);
        }

        public void removeTuioObject(TuioObject o)
        {
            lock (objectList)
            {
                objectList.Remove(o.SessionID);
            }
            if (verbose) Console.WriteLine("del obj " + o.SymbolID + " (" + o.SessionID + ")");
        }

        public void addTuioCursor(TuioCursor c)
        {
            lock (cursorList)
            {
                cursorList.Add(c.SessionID, c);
            }
            if (verbose) Console.WriteLine("add cur " + c.CursorID + " (" + c.SessionID + ") " + c.X + " " + c.Y);
        }

        public void updateTuioCursor(TuioCursor c)
        {
            if (verbose) Console.WriteLine("set cur " + c.CursorID + " (" + c.SessionID + ") " + c.X + " " + c.Y + " " + c.MotionSpeed + " " + c.MotionAccel);
        }

        public void removeTuioCursor(TuioCursor c)
        {
            lock (cursorList)
            {
                cursorList.Remove(c.SessionID);
            }
            if (verbose) Console.WriteLine("del cur " + c.CursorID + " (" + c.SessionID + ")");
        }

        public void addTuioBlob(TuioBlob b)
        {
            lock (blobList)
            {
                blobList.Add(b.SessionID, b);
            }
            if (verbose) Console.WriteLine("add blb " + b.BlobID + " (" + b.SessionID + ") " + b.X + " " + b.Y + " " + b.Angle + " " + b.Width + " " + b.Height + " " + b.Area);
        }

        public void updateTuioBlob(TuioBlob b)
        {

            if (verbose) Console.WriteLine("set blb " + b.BlobID + " (" + b.SessionID + ") " + b.X + " " + b.Y + " " + b.Angle + " " + b.Width + " " + b.Height + " " + b.Area + " " + b.MotionSpeed + " " + b.RotationSpeed + " " + b.MotionAccel + " " + b.RotationAccel);
        }

        private void TuioDemo_Load_1(object sender, EventArgs e)
        {
            
        }

        public void removeTuioBlob(TuioBlob b)
        {
            lock (blobList)
            {
                blobList.Remove(b.SessionID);
            }
            if (verbose) Console.WriteLine("del blb " + b.BlobID + " (" + b.SessionID + ")");
        }

        public void refresh(TuioTime frameTime)
        {
            Invalidate();
        }

        protected override void OnPaintBackground(PaintEventArgs pevent)
        {
            // Getting the graphics object
            Graphics g = pevent.Graphics;
            g.FillRectangle(bgrBrush, new Rectangle(0, 0, width, height));

            // draw the cursor path
            if (cursorList.Count > 0)
            {
                lock (cursorList)
                {
                    foreach (TuioCursor tcur in cursorList.Values)
                    {
                        List<TuioPoint> path = tcur.Path;
                        TuioPoint current_point = path[0];

                        for (int i = 0; i < path.Count; i++)
                        {
                            TuioPoint next_point = path[i];
                            g.DrawLine(curPen, current_point.getScreenX(width), current_point.getScreenY(height), next_point.getScreenX(width), next_point.getScreenY(height));
                            current_point = next_point;
                        }
                        g.FillEllipse(curBrush, current_point.getScreenX(width) - height / 100, current_point.getScreenY(height) - height / 100, height / 50, height / 50);
                        g.DrawString(tcur.CursorID + "", font, fntBrush, new PointF(tcur.getScreenX(width) - 10, tcur.getScreenY(height) - 10));
                    }
                }
            }

            // draw the objects
            if (objectList.Count > 0)
            {
                lock (objectList)
                {
                    foreach (TuioObject tobj in objectList.Values)
                    {
                        int ox = tobj.getScreenX(width);
                        int oy = tobj.getScreenY(height);
                        x = ox;
                        y = oy;
                        int size = height / 10;
                        //Bitmap img;
                        // Bitmap img_cage;
                        //if (tobj.SymbolID == 0&&flag_arrive==0)
                        //{

                        //x_cage = 0;
                        //y_cage = 100;
                        //img_cage = new Bitmap("lionhouse.bmp");
                        //img_cage.MakeTransparent(Color.White);
                        //img_cage.MakeTransparent(img_cage.GetPixel(0, 0));
                        // g.DrawImage(img_cage, x_cage, y_cage, 150, 150);

                        //}
                        g.TranslateTransform(ox, oy);
                        g.RotateTransform((float)(tobj.Angle / Math.PI * 180.0f));
                        g.TranslateTransform(-ox, -oy);
                        if (tobj.SymbolID == 0)
                        {
                            img = new Bitmap("lion.bmp");
                            img.MakeTransparent(System.Drawing.Color.White);
                            img.MakeTransparent(img.GetPixel(0, 0));
                            g.DrawImage(img, ox - 50, oy - 50, 150, 150);
                            if (x - 50 >= x_lionhouse && x - 50 <= x_lionhouse + 150 && y - 50 >= y_lionhouse && y - 50 <= y_lionhouse + 150)
                            {
                                flag_arrive1 = 1;
                                if (flag_arrive1 == 1)
                                {
                                    x_lionhouse = 50;
                                    y_lionhouse = 400;
                                    img_lionhouse = new Bitmap("lion house2.bmp");
                                    img_lionhouse.MakeTransparent(System.Drawing.Color.White);
                                    img_lionhouse.MakeTransparent(img_lionhouse.GetPixel(0, 0));
                                    flag_arrive1 = 0;
                                    MediaPlayer mediaPlayer = new MediaPlayer();
                                    string path = Path.Combine(Environment.CurrentDirectory, "Winning Sound Effect.mp3");
                                    mediaPlayer.Open(new Uri("C:\\Users\\DELL\\OneDrive\\Desktop\\Lab 4 - TUIO-20231029\\TUIO11_NET-master\\TUIO11_NET-master\\bin\\Debug\\Winning Sound Effect.mp3"));
                                    mediaPlayer.Play();
                                    //mediaPlayer.Stop();
                                }
                                //mediaPlayer.Stop();
                            }

                            if (x - 50 >= x_monkeyhouse && x - 50 <= x_monkeyhouse + 150 && y - 50 >= y_monkeyhouse && y - 50 <= y_monkeyhouse + 150)
                               
                            {
                                MediaPlayer mediaPlayer = new MediaPlayer();
                                string path = Path.Combine(Environment.CurrentDirectory, "Winning Sound Effect.mp3");
                                mediaPlayer.Open(new Uri("C:\\Users\\DELL\\OneDrive\\Desktop\\Lab 4 - TUIO-20231029\\TUIO11_NET-master\\TUIO11_NET-master\\bin\\Debug\\sound of loss.mp3"));
                                mediaPlayer.Play();
                                System.IO.File.WriteAllText("C:\\Users\\DELL\\OneDrive\\Desktop\\Lab 4 - TUIO-20231029\\TUIO11_NET-master\\TUIO11_NET-master\\bin\\Debug\\test.txt", string.Empty);

                                if (!messageBoxShownMonkey)
                                {
                                        messageBoxShownMonkey = true;
                                        MessageBox.Show("Error: Wrong unfortunately... If you need to restart, please form a circle with your hand");
                                        c.closeConnection();
                                        System.Windows.Forms.Application.Restart();
                                        Environment.Exit(0);
                                       string text = System.IO.File.ReadAllText("C:\\Users\\DELL\\OneDrive\\Desktop\\Lab 4 - TUIO-20231029\\TUIO11_NET-master\\TUIO11_NET-master\\bin\\Debug\\test.txt");
                                       string[] lines = System.IO.File.ReadAllLines(path);
                                    if (lines.Length > 0)
                                    {
                                        if (lines[lines.Length].ToLower().Contains("right"))
                                        {
                                            string lastLine = lines[lines.Length - 1];
                                            Connect connect = new Connect();
                                            connect.connectToSocket("127.0.0.1", 5009);
                                        }
                                    }

                                   
                                }
                                 
                                //MessageBox.Show("Error: Conditions not met.");
                                //g.DrawString("Wrong unfortunately... If you need to restart, please form a circle with your hand", font, fntBrush, new PointF(100, 100));
                            }
                            if (x - 50 >= x_rabbithouse && x - 50 <= x_rabbithouse + 200 && y - 50 >= y_rabbithouse && y - 50 <= y_rabbithouse + 200)
                            {
                                MediaPlayer mediaPlayer = new MediaPlayer();
                                string path = Path.Combine(Environment.CurrentDirectory, "Winning Sound Effect.mp3");
                                mediaPlayer.Open(new Uri("C:\\Users\\DELL\\OneDrive\\Desktop\\Lab 4 - TUIO-20231029\\TUIO11_NET-master\\TUIO11_NET-master\\bin\\Debug\\sound of loss.mp3"));
                                mediaPlayer.Play();
                                if (!messageBoxShownRabbit)
                                {
                                    messageBoxShownRabbit = true;
                                    MessageBox.Show("Error: Wrong unfortunately... If you need to restart, please form a circle with your hand");
                                    c.closeConnection();
                                    System.Windows.Forms.Application.Restart();
                                    Environment.Exit(0);
                                    string text = System.IO.File.ReadAllText("C:\\Users\\DELL\\OneDrive\\Desktop\\Lab 4 - TUIO-20231029\\TUIO11_NET-master\\TUIO11_NET-master\\bin\\Debug\\test.txt");
                                    string[] lines = System.IO.File.ReadAllLines(path);
                                    if (lines.Length > 0)
                                    {
                                        if (lines[lines.Length].ToLower().Contains("right"))
                                        {
                                            string lastLine = lines[lines.Length - 1];
                                            Connect connect = new Connect();
                                            connect.connectToSocket("127.0.0.1", 5009);
                                        }
                                    }


                                }

                            }
                            if (x - 50 >= x_birdhouse && x - 50 <= x_birdhouse + 150 && y - 50 >= y_birdhouse && y - 50 <= y_birdhouse + 150)
                            {
                                MediaPlayer mediaPlayer = new MediaPlayer();
                                string path = Path.Combine(Environment.CurrentDirectory, "Winning Sound Effect.mp3");
                                mediaPlayer.Open(new Uri("C:\\Users\\DELL\\OneDrive\\Desktop\\Lab 4 - TUIO-20231029\\TUIO11_NET-master\\TUIO11_NET-master\\bin\\Debug\\sound of loss.mp3"));
                                mediaPlayer.Play();
                                if (!messageBoxShownBird)
                                {
                                    messageBoxShownBird = true;
                                    MessageBox.Show("Error: Wrong unfortunately... If you need to restart, please form a circle with your hand");
                                    c.closeConnection();
                                    System.Windows.Forms.Application.Restart();
                                    Environment.Exit(0);
                                    string text = System.IO.File.ReadAllText("C:\\Users\\DELL\\OneDrive\\Desktop\\Lab 4 - TUIO-20231029\\TUIO11_NET-master\\TUIO11_NET-master\\bin\\Debug\\test.txt");
                                    string[] lines = System.IO.File.ReadAllLines(path);
                                    if (lines.Length > 0)
                                    {
                                        if (lines[lines.Length].ToLower().Contains("right"))
                                        {
                                            string lastLine = lines[lines.Length - 1];
                                            Connect connect = new Connect();
                                            connect.connectToSocket("127.0.0.1", 5009);
                                        }
                                    }

                                }

                            }
                            if (x - 50 >= x_doghouse && x - 50 <= x_doghouse + 150 && y - 50 >= y_doghouse && y - 50 <= y_doghouse + 150)
                            {
                                MediaPlayer mediaPlayer = new MediaPlayer();
                                string path = Path.Combine(Environment.CurrentDirectory, "Winning Sound Effect.mp3");
                                mediaPlayer.Open(new Uri("C:\\Users\\DELL\\OneDrive\\Desktop\\Lab 4 - TUIO-20231029\\TUIO11_NET-master\\TUIO11_NET-master\\bin\\Debug\\sound of loss.mp3"));
                                mediaPlayer.Play();
                                if (!messageBoxShownDog)
                                {
                                    messageBoxShownDog = true;
                                    MessageBox.Show("Error: Wrong unfortunately... If you need to restart, please form a circle with your hand");
                                    c.closeConnection();
                                    System.Windows.Forms.Application.Restart();
                                    Environment.Exit(0);
                                    string text = System.IO.File.ReadAllText("C:\\Users\\DELL\\OneDrive\\Desktop\\Lab 4 - TUIO-20231029\\TUIO11_NET-master\\TUIO11_NET-master\\bin\\Debug\\test.txt");
                                    string[] lines = System.IO.File.ReadAllLines(path);
                                    if (lines.Length > 0)
                                    {
                                        if (lines[lines.Length].ToLower().Contains("right"))
                                        {
                                            string lastLine = lines[lines.Length - 1];
                                            Connect connect = new Connect();
                                            connect.connectToSocket("127.0.0.1", 5009);
                                        }
                                    }

                                }

                            }
                          
                        }
                        if (tobj.SymbolID == 1)
                        {
                            img = new Bitmap("monkey.bmp");
                            img.MakeTransparent(System.Drawing.Color.White);
                            img.MakeTransparent(img.GetPixel(0, 0));
                            g.DrawImage(img, ox - 50, oy - 50, 150, 150);
                            if (x - 50 >= x_monkeyhouse && x - 50 <= x_monkeyhouse + 150 && y - 50 >= y_monkeyhouse && y - 50 <= y_monkeyhouse + 150)
                            {
                                flag_arrive5 = 5;
                                if (flag_arrive5 == 5)
                                {
                                    x_monkeyhouse = 400;
                                    y_monkeyhouse = 50;
                                    img_monkeyhouse = new Bitmap("monkeyhouse2.bmp");
                                    img_monkeyhouse.MakeTransparent(System.Drawing.Color.White);
                                    img_monkeyhouse.MakeTransparent(img_monkeyhouse.GetPixel(0, 0));
                                    flag_arrive5 = 0;
                                    MediaPlayer mediaPlayer = new MediaPlayer();
                                    string path = Path.Combine(Environment.CurrentDirectory, "Winning Sound Effect.mp3");
                                    mediaPlayer.Open(new Uri("C:\\Users\\DELL\\OneDrive\\Desktop\\Lab 4 - TUIO-20231029\\TUIO11_NET-master\\TUIO11_NET-master\\bin\\Debug\\Winning Sound Effect.mp3"));
                                    mediaPlayer.Play();
                                }
                            }
                            if (x - 50 >= x_lionhouse && x - 50 <= x_lionhouse + 150 && y - 50 >= y_lionhouse && y - 50 <= y_lionhouse + 150)

                            {
                                MediaPlayer mediaPlayer = new MediaPlayer();
                                string path = Path.Combine(Environment.CurrentDirectory, "Winning Sound Effect.mp3");
                                mediaPlayer.Open(new Uri("C:\\Users\\DELL\\OneDrive\\Desktop\\Lab 4 - TUIO-20231029\\TUIO11_NET-master\\TUIO11_NET-master\\bin\\Debug\\sound of loss.mp3"));
                                mediaPlayer.Play();

                                if (!messageBoxShownMonkey)
                                {
                                    messageBoxShownMonkey = true;
                                    MessageBox.Show("Error: Wrong unfortunately... If you need to restart, please form a circle with your hand");
                                    c.closeConnection();
                                    System.Windows.Forms.Application.Restart();
                                    Environment.Exit(0);
                                    string text = System.IO.File.ReadAllText("C:\\Users\\DELL\\OneDrive\\Desktop\\Lab 4 - TUIO-20231029\\TUIO11_NET-master\\TUIO11_NET-master\\bin\\Debug\\test.txt");
                                    string[] lines = System.IO.File.ReadAllLines(path);
                                    if (lines.Length > 0)
                                    {
                                        if (lines[lines.Length].ToLower().Contains("right"))
                                        {
                                            string lastLine = lines[lines.Length - 1];
                                            Connect connect = new Connect();
                                            connect.connectToSocket("127.0.0.1", 5009);
                                        }
                                    }

                                }

                                //MessageBox.Show("Error: Conditions not met.");
                                //g.DrawString("Wrong unfortunately... If you need to restart, please form a circle with your hand", font, fntBrush, new PointF(100, 100));
                            }
                            if (x - 50 >= x_rabbithouse && x - 50 <= x_rabbithouse + 200 && y - 50 >= y_rabbithouse && y - 50 <= y_rabbithouse + 200)
                            {
                                MediaPlayer mediaPlayer = new MediaPlayer();
                                string path = Path.Combine(Environment.CurrentDirectory, "Winning Sound Effect.mp3");
                                mediaPlayer.Open(new Uri("C:\\Users\\DELL\\OneDrive\\Desktop\\Lab 4 - TUIO-20231029\\TUIO11_NET-master\\TUIO11_NET-master\\bin\\Debug\\sound of loss.mp3"));
                                mediaPlayer.Play();
                                if (!messageBoxShownRabbit)
                                {
                                    messageBoxShownRabbit = true;
                                    MessageBox.Show("Error: Wrong unfortunately... If you need to restart, please form a circle with your hand");
                                    c.closeConnection();
                                    System.Windows.Forms.Application.Restart();
                                    Environment.Exit(0);
                                    string text = System.IO.File.ReadAllText("C:\\Users\\DELL\\OneDrive\\Desktop\\Lab 4 - TUIO-20231029\\TUIO11_NET-master\\TUIO11_NET-master\\bin\\Debug\\test.txt");
                                    string[] lines = System.IO.File.ReadAllLines(path);
                                    if (lines.Length > 0)
                                    {
                                        if (lines[lines.Length].ToLower().Contains("right"))
                                        {
                                            string lastLine = lines[lines.Length - 1];
                                            Connect connect = new Connect();
                                            connect.connectToSocket("127.0.0.1", 5009);
                                        }
                                    }

                                }

                            }
                            if (x - 50 >= x_birdhouse && x - 50 <= x_birdhouse + 150 && y - 50 >= y_birdhouse && y - 50 <= y_birdhouse + 150)
                            {
                                MediaPlayer mediaPlayer = new MediaPlayer();
                                string path = Path.Combine(Environment.CurrentDirectory, "Winning Sound Effect.mp3");
                                mediaPlayer.Open(new Uri("C:\\Users\\DELL\\OneDrive\\Desktop\\Lab 4 - TUIO-20231029\\TUIO11_NET-master\\TUIO11_NET-master\\bin\\Debug\\sound of loss.mp3"));
                                mediaPlayer.Play();
                                if (messageBoxShownBird)
                                {
                                    messageBoxShownBird = true;
                                    MessageBox.Show("Error: Wrong unfortunately... If you need to restart, please form a circle with your hand");
                                    string text = System.IO.File.ReadAllText("C:\\Users\\DELL\\OneDrive\\Desktop\\Lab 4 - TUIO-20231029\\TUIO11_NET-master\\TUIO11_NET-master\\bin\\Debug\\test.txt");
                                    if (text.ToLower().Contains("Right"))
                                    {
                                        c.closeConnection();
                                        System.Windows.Forms.Application.Restart();
                                        Environment.Exit(0);

                                        Connect connect = new Connect();
                                        connect.connectToSocket("127.0.0.1", 5009);
                                    }
                                }

                            }
                            if (x - 50 >= x_doghouse && x - 50 <= x_doghouse + 150 && y - 50 >= y_doghouse && y - 50 <= y_doghouse + 150)
                            {
                                MediaPlayer mediaPlayer = new MediaPlayer();
                                string path = Path.Combine(Environment.CurrentDirectory, "Winning Sound Effect.mp3");
                                mediaPlayer.Open(new Uri("C:\\Users\\DELL\\OneDrive\\Desktop\\Lab 4 - TUIO-20231029\\TUIO11_NET-master\\TUIO11_NET-master\\bin\\Debug\\sound of loss.mp3"));
                                mediaPlayer.Play();
                                if (!messageBoxShownDog)
                                {
                                    messageBoxShownDog = true;
                                    MessageBox.Show("Error: Wrong unfortunately... If you need to restart, please form a circle with your hand");
                                    c.closeConnection();
                                    System.Windows.Forms.Application.Restart();
                                    Environment.Exit(0);
                                    string text = System.IO.File.ReadAllText("C:\\Users\\DELL\\OneDrive\\Desktop\\Lab 4 - TUIO-20231029\\TUIO11_NET-master\\TUIO11_NET-master\\bin\\Debug\\test.txt");
                                    string[] lines = System.IO.File.ReadAllLines(path);
                                    if (lines.Length > 0)
                                    {
                                        if (lines[lines.Length].ToLower().Contains("right"))
                                        {
                                            string lastLine = lines[lines.Length - 1];
                                            Connect connect = new Connect();
                                            connect.connectToSocket("127.0.0.1", 5009);
                                        }
                                    }

                                }

                            }
                        }

                        if (tobj.SymbolID == 2)
                        {
                            img = new Bitmap("rabbit.bmp");
                            img.MakeTransparent(System.Drawing.Color.White);
                            img.MakeTransparent(img.GetPixel(0, 0));
                            g.DrawImage(img, ox - 50, oy - 50, 200, 200);
                            if (x - 50 >= x_rabbithouse && x - 50 <= x_rabbithouse + 200 && y - 50 >= y_rabbithouse && y - 50 <= y_rabbithouse + 200)
                            {
                                flag_arrive3 = 3;
                                if (flag_arrive3 == 3)
                                {
                                    x_rabbithouse = 1300;
                                    y_rabbithouse = 400;
                                    img_rabbithouse = new Bitmap("rabbit house2.bmp");
                                    img_rabbithouse.MakeTransparent(System.Drawing.Color.White);
                                    img_rabbithouse.MakeTransparent(img_rabbithouse.GetPixel(0, 0));
                                    flag_arrive3 = 0;
                                    MediaPlayer mediaPlayer = new MediaPlayer();
                                    string path = Path.Combine(Environment.CurrentDirectory, "Winning Sound Effect.mp3");
                                    mediaPlayer.Open(new Uri("C:\\Users\\DELL\\OneDrive\\Desktop\\Lab 4 - TUIO-20231029\\TUIO11_NET-master\\TUIO11_NET-master\\bin\\Debug\\Winning Sound Effect.mp3"));
                                    mediaPlayer.Play();
                                }
                            }
                            if (x - 50 >= x_monkeyhouse && x - 50 <= x_monkeyhouse + 150 && y - 50 >= y_monkeyhouse && y - 50 <= y_monkeyhouse + 150)

                            {
                                MediaPlayer mediaPlayer = new MediaPlayer();
                                string path = Path.Combine(Environment.CurrentDirectory, "Winning Sound Effect.mp3");
                                mediaPlayer.Open(new Uri("C:\\Users\\DELL\\OneDrive\\Desktop\\Lab 4 - TUIO-20231029\\TUIO11_NET-master\\TUIO11_NET-master\\bin\\Debug\\sound of loss.mp3"));
                                mediaPlayer.Play();

                                if (!messageBoxShownMonkey)
                                {
                                    messageBoxShownMonkey = true;
                                    MessageBox.Show("Error: Wrong unfortunately... If you need to restart, please form a circle with your hand");
                                    c.closeConnection();
                                    System.Windows.Forms.Application.Restart();
                                    Environment.Exit(0);
                                    string text = System.IO.File.ReadAllText("C:\\Users\\DELL\\OneDrive\\Desktop\\Lab 4 - TUIO-20231029\\TUIO11_NET-master\\TUIO11_NET-master\\bin\\Debug\\test.txt");
                                    string[] lines = System.IO.File.ReadAllLines(path);
                                    if (lines.Length > 0)
                                    {
                                        if (lines[lines.Length].ToLower().Contains("right"))
                                        {
                                            string lastLine = lines[lines.Length - 1];
                                            Connect connect = new Connect();
                                            connect.connectToSocket("127.0.0.1", 5009);
                                        }
                                    }

                                }

                                //MessageBox.Show("Error: Conditions not met.");
                                //g.DrawString("Wrong unfortunately... If you need to restart, please form a circle with your hand", font, fntBrush, new PointF(100, 100));
                            }
                            if (x - 50 >= x_lionhouse && x - 50 <= x_lionhouse + 200 && y - 50 >= y_rabbithouse && y - 50 <= y_rabbithouse + 200)
                            {
                                MediaPlayer mediaPlayer = new MediaPlayer();
                                string path = Path.Combine(Environment.CurrentDirectory, "Winning Sound Effect.mp3");
                                mediaPlayer.Open(new Uri("C:\\Users\\DELL\\OneDrive\\Desktop\\Lab 4 - TUIO-20231029\\TUIO11_NET-master\\TUIO11_NET-master\\bin\\Debug\\sound of loss.mp3"));
                                mediaPlayer.Play();
                                if (!messageBoxShownRabbit)
                                {
                                    messageBoxShownRabbit = true;
                                    MessageBox.Show("Error: Wrong unfortunately... If you need to restart, please form a circle with your hand");
                                    c.closeConnection();
                                    System.Windows.Forms.Application.Restart();
                                    Environment.Exit(0);
                                    string text = System.IO.File.ReadAllText("C:\\Users\\DELL\\OneDrive\\Desktop\\Lab 4 - TUIO-20231029\\TUIO11_NET-master\\TUIO11_NET-master\\bin\\Debug\\test.txt");
                                    string[] lines = System.IO.File.ReadAllLines(path);
                                    if (lines.Length > 0)
                                    {
                                        if (lines[lines.Length].ToLower().Contains("right"))
                                        {
                                            string lastLine = lines[lines.Length - 1];
                                            Connect connect = new Connect();
                                            connect.connectToSocket("127.0.0.1", 5009);
                                        }
                                    }

                                }

                            }
                            if (x - 50 >= x_birdhouse && x - 50 <= x_birdhouse + 150 && y - 50 >= y_birdhouse && y - 50 <= y_birdhouse + 150)
                            {
                                MediaPlayer mediaPlayer = new MediaPlayer();
                                string path = Path.Combine(Environment.CurrentDirectory, "Winning Sound Effect.mp3");
                                mediaPlayer.Open(new Uri("C:\\Users\\DELL\\OneDrive\\Desktop\\Lab 4 - TUIO-20231029\\TUIO11_NET-master\\TUIO11_NET-master\\bin\\Debug\\sound of loss.mp3"));
                                mediaPlayer.Play();
                                if (messageBoxShownBird)
                                {
                                    messageBoxShownBird = true;
                                    MessageBox.Show("Error: Wrong unfortunately... If you need to restart, please form a circle with your hand");
                                    c.closeConnection();
                                    System.Windows.Forms.Application.Restart();
                                    Environment.Exit(0);
                                    string text = System.IO.File.ReadAllText("C:\\Users\\DELL\\OneDrive\\Desktop\\Lab 4 - TUIO-20231029\\TUIO11_NET-master\\TUIO11_NET-master\\bin\\Debug\\test.txt");
                                    string[] lines = System.IO.File.ReadAllLines(path);
                                    if (lines.Length > 0)
                                    {
                                        if (lines[lines.Length].ToLower().Contains("right"))
                                        {
                                            string lastLine = lines[lines.Length - 1];
                                            Connect connect = new Connect();
                                            connect.connectToSocket("127.0.0.1", 5009);
                                        }
                                    }

                                }

                            }
                            if (x - 50 >= x_doghouse && x - 50 <= x_doghouse + 150 && y - 50 >= y_doghouse && y - 50 <= y_doghouse + 150)
                            {
                                MediaPlayer mediaPlayer = new MediaPlayer();
                                string path = Path.Combine(Environment.CurrentDirectory, "Winning Sound Effect.mp3");
                                mediaPlayer.Open(new Uri("C:\\Users\\DELL\\OneDrive\\Desktop\\Lab 4 - TUIO-20231029\\TUIO11_NET-master\\TUIO11_NET-master\\bin\\Debug\\sound of loss.mp3"));
                                mediaPlayer.Play();
                                if (!messageBoxShownDog)
                                {
                                    messageBoxShownDog = true;
                                    MessageBox.Show("Error: Wrong unfortunately... If you need to restart, please form a circle with your hand");
                                    c.closeConnection();
                                    System.Windows.Forms.Application.Restart();
                                    Environment.Exit(0);
                                    string text = System.IO.File.ReadAllText("C:\\Users\\DELL\\OneDrive\\Desktop\\Lab 4 - TUIO-20231029\\TUIO11_NET-master\\TUIO11_NET-master\\bin\\Debug\\test.txt");
                                    string[] lines = System.IO.File.ReadAllLines(path);
                                    if (lines.Length > 0)
                                    {
                                        if (lines[lines.Length].ToLower().Contains("right"))
                                        {
                                            string lastLine = lines[lines.Length - 1];
                                            Connect connect = new Connect();
                                            connect.connectToSocket("127.0.0.1", 5009);
                                        }
                                    }

                                }

                            }
                        }
                        if (tobj.SymbolID == 3)
                        {
                            img = new Bitmap("bird.bmp");
                            img.MakeTransparent(System.Drawing.Color.White);
                            img.MakeTransparent(img.GetPixel(0, 0));
                            g.DrawImage(img, ox - 50, oy - 50, 150, 150);
                            if (x - 50 >= x_birdhouse && x - 50 <= x_birdhouse + 150 && y - 50 >= y_birdhouse && y - 50 <= y_birdhouse + 150)
                            {
                                flag_arrive2 = 2;
                                if (flag_arrive2 == 2)
                                {
                                    x_birdhouse = 700;
                                    y_birdhouse = 600;
                                    img_birdhouse = new Bitmap("bird house2.bmp");
                                    img_birdhouse.MakeTransparent(System.Drawing.Color.White);
                                    img_lionhouse.MakeTransparent(img_birdhouse.GetPixel(0, 0));
                                    flag_arrive2 = 0;
                                    MediaPlayer mediaPlayer = new MediaPlayer();
                                    string path = Path.Combine(Environment.CurrentDirectory, "Winning Sound Effect.mp3");
                                    mediaPlayer.Open(new Uri("C:\\Users\\DELL\\OneDrive\\Desktop\\Lab 4 - TUIO-20231029\\TUIO11_NET-master\\TUIO11_NET-master\\bin\\Debug\\Winning Sound Effect.mp3"));
                                    mediaPlayer.Play();
                                }
                            }
                            if (x - 50 >= x_monkeyhouse && x - 50 <= x_monkeyhouse + 150 && y - 50 >= y_monkeyhouse && y - 50 <= y_monkeyhouse + 150)

                            {
                                MediaPlayer mediaPlayer = new MediaPlayer();
                                string path = Path.Combine(Environment.CurrentDirectory, "Winning Sound Effect.mp3");
                                mediaPlayer.Open(new Uri("C:\\Users\\DELL\\OneDrive\\Desktop\\Lab 4 - TUIO-20231029\\TUIO11_NET-master\\TUIO11_NET-master\\bin\\Debug\\sound of loss.mp3"));
                                mediaPlayer.Play();

                                if (!messageBoxShownMonkey)
                                {
                                    messageBoxShownMonkey = true;
                                    MessageBox.Show("Error: Wrong unfortunately... If you need to restart, please form a circle with your hand");
                                    c.closeConnection();
                                    System.Windows.Forms.Application.Restart();
                                    Environment.Exit(0);
                                    string text = System.IO.File.ReadAllText("C:\\Users\\DELL\\OneDrive\\Desktop\\Lab 4 - TUIO-20231029\\TUIO11_NET-master\\TUIO11_NET-master\\bin\\Debug\\test.txt");
                                    string[] lines = System.IO.File.ReadAllLines(path);
                                    if (lines.Length > 0)
                                    {
                                        if (lines[lines.Length].ToLower().Contains("right"))
                                        {
                                            string lastLine = lines[lines.Length - 1];
                                            Connect connect = new Connect();
                                            connect.connectToSocket("127.0.0.1", 5009);
                                        }
                                    }

                                }

                                //MessageBox.Show("Error: Conditions not met.");
                                //g.DrawString("Wrong unfortunately... If you need to restart, please form a circle with your hand", font, fntBrush, new PointF(100, 100));
                            }
                            if (x - 50 >= x_rabbithouse && x - 50 <= x_rabbithouse + 200 && y - 50 >= y_rabbithouse && y - 50 <= y_rabbithouse + 200)
                            {
                                MediaPlayer mediaPlayer = new MediaPlayer();
                                string path = Path.Combine(Environment.CurrentDirectory, "Winning Sound Effect.mp3");
                                mediaPlayer.Open(new Uri("C:\\Users\\DELL\\OneDrive\\Desktop\\Lab 4 - TUIO-20231029\\TUIO11_NET-master\\TUIO11_NET-master\\bin\\Debug\\sound of loss.mp3"));
                                mediaPlayer.Play();
                                if (!messageBoxShownRabbit)
                                {
                                    messageBoxShownRabbit = true;
                                    MessageBox.Show("Error: Wrong unfortunately... If you need to restart, please form a circle with your hand");
                                    c.closeConnection();
                                    System.Windows.Forms.Application.Restart();
                                    Environment.Exit(0);
                                    string text = System.IO.File.ReadAllText("C:\\Users\\DELL\\OneDrive\\Desktop\\Lab 4 - TUIO-20231029\\TUIO11_NET-master\\TUIO11_NET-master\\bin\\Debug\\test.txt");
                                    string[] lines = System.IO.File.ReadAllLines(path);
                                    if (lines.Length > 0)
                                    {
                                        if (lines[lines.Length].ToLower().Contains("right"))
                                        {
                                            string lastLine = lines[lines.Length - 1];
                                            Connect connect = new Connect();
                                            connect.connectToSocket("127.0.0.1", 5009);
                                        }
                                    }

                                }

                            }
                            if (x - 50 >= x_lionhouse && x - 50 <= x_lionhouse + 150 && y - 50 >= y_lionhouse && y - 50 <= y_lionhouse + 150)
                            {
                                MediaPlayer mediaPlayer = new MediaPlayer();
                                string path = Path.Combine(Environment.CurrentDirectory, "Winning Sound Effect.mp3");
                                mediaPlayer.Open(new Uri("C:\\Users\\DELL\\OneDrive\\Desktop\\Lab 4 - TUIO-20231029\\TUIO11_NET-master\\TUIO11_NET-master\\bin\\Debug\\sound of loss.mp3"));
                                mediaPlayer.Play();
                                if (messageBoxShownBird)
                                {
                                    messageBoxShownBird = true;
                                    MessageBox.Show("Error: Wrong unfortunately... If you need to restart, please form a circle with your hand");
                                    c.closeConnection();
                                    System.Windows.Forms.Application.Restart();
                                    Environment.Exit(0);
                                    string text = System.IO.File.ReadAllText("C:\\Users\\DELL\\OneDrive\\Desktop\\Lab 4 - TUIO-20231029\\TUIO11_NET-master\\TUIO11_NET-master\\bin\\Debug\\test.txt");
                                    string[] lines = System.IO.File.ReadAllLines(path);
                                    if (lines.Length > 0)
                                    {
                                        if (lines[lines.Length].ToLower().Contains("right"))
                                        {
                                            string lastLine = lines[lines.Length - 1];
                                            Connect connect = new Connect();
                                            connect.connectToSocket("127.0.0.1", 5009);
                                        }
                                    }

                                }

                            }
                            if (x - 50 >= x_doghouse && x - 50 <= x_doghouse + 150 && y - 50 >= y_doghouse && y - 50 <= y_doghouse + 150)
                            {
                                MediaPlayer mediaPlayer = new MediaPlayer();
                                string path = Path.Combine(Environment.CurrentDirectory, "Winning Sound Effect.mp3");
                                mediaPlayer.Open(new Uri("C:\\Users\\DELL\\OneDrive\\Desktop\\Lab 4 - TUIO-20231029\\TUIO11_NET-master\\TUIO11_NET-master\\bin\\Debug\\sound of loss.mp3"));
                                mediaPlayer.Play();
                                if (!messageBoxShownDog)
                                {
                                    messageBoxShownDog = true;
                                    MessageBox.Show("Error: Wrong unfortunately... If you need to restart, please form a circle with your hand");
                                    c.closeConnection();
                                    System.Windows.Forms.Application.Restart();
                                    Environment.Exit(0);
                                    string text = System.IO.File.ReadAllText("C:\\Users\\DELL\\OneDrive\\Desktop\\Lab 4 - TUIO-20231029\\TUIO11_NET-master\\TUIO11_NET-master\\bin\\Debug\\test.txt");
                                    string[] lines = System.IO.File.ReadAllLines(path);
                                    if (lines.Length > 0)
                                    {
                                        if (lines[lines.Length].ToLower().Contains("right"))
                                        {
                                            string lastLine = lines[lines.Length - 1];
                                            Connect connect = new Connect();
                                            connect.connectToSocket("127.0.0.1", 5009);
                                        }
                                    }

                                }

                            }
                        }
                        if (tobj.SymbolID == 4)
                        {
                            img = new Bitmap("dog.bmp");
                            img.MakeTransparent(System.Drawing.Color.White);
                            img.MakeTransparent(img.GetPixel(0, 0));
                            g.DrawImage(img, ox - 50, oy - 50, 150, 150);
                            if (x - 50 >= x_doghouse && x - 50 <= x_doghouse + 150 && y - 50 >= y_doghouse && y - 50 <= y_doghouse + 150)
                            {
                                flag_arrive4 = 4;
                                if (flag_arrive4 == 4)
                                {
                                    x_doghouse = 1000;
                                    y_doghouse = 50;
                                    img_doghouse = new Bitmap("doghouse2.bmp");
                                    img_doghouse.MakeTransparent(System.Drawing.Color.White);
                                    img_doghouse.MakeTransparent(img_doghouse.GetPixel(0, 0));
                                    flag_arrive4 = 0;
                                    MediaPlayer mediaPlayer = new MediaPlayer();
                                    string path = Path.Combine(Environment.CurrentDirectory, "Winning Sound Effect.mp3");
                                    mediaPlayer.Open(new Uri("C:\\Users\\DELL\\OneDrive\\Desktop\\Lab 4 - TUIO-20231029\\TUIO11_NET-master\\TUIO11_NET-master\\bin\\Debug\\Winning Sound Effect.mp3"));
                                    mediaPlayer.Play();
                                }
                            }
                            if (x - 50 >= x_monkeyhouse && x - 50 <= x_monkeyhouse + 150 && y - 50 >= y_monkeyhouse && y - 50 <= y_monkeyhouse + 150)

                            {
                                MediaPlayer mediaPlayer = new MediaPlayer();
                                string path = Path.Combine(Environment.CurrentDirectory, "Winning Sound Effect.mp3");
                                mediaPlayer.Open(new Uri("C:\\Users\\DELL\\OneDrive\\Desktop\\Lab 4 - TUIO-20231029\\TUIO11_NET-master\\TUIO11_NET-master\\bin\\Debug\\sound of loss.mp3"));
                                mediaPlayer.Play();

                                if (!messageBoxShownMonkey)
                                {
                                    messageBoxShownMonkey = true;
                                    MessageBox.Show("Error: Wrong unfortunately... If you need to restart, please form a circle with your hand");
                                    c.closeConnection();
                                    System.Windows.Forms.Application.Restart();
                                    Environment.Exit(0);
                                    string text = System.IO.File.ReadAllText("C:\\Users\\DELL\\OneDrive\\Desktop\\Lab 4 - TUIO-20231029\\TUIO11_NET-master\\TUIO11_NET-master\\bin\\Debug\\test.txt");
                                    string[] lines = System.IO.File.ReadAllLines(path);
                                    if (lines.Length > 0)
                                    {
                                        if (lines[lines.Length].ToLower().Contains("right"))
                                        {
                                            string lastLine = lines[lines.Length - 1];
                                            Connect connect = new Connect();
                                            connect.connectToSocket("127.0.0.1", 5009);
                                        }
                                    }

                                }

                                //MessageBox.Show("Error: Conditions not met.");
                                //g.DrawString("Wrong unfortunately... If you need to restart, please form a circle with your hand", font, fntBrush, new PointF(100, 100));
                            }
                            if (x - 50 >= x_rabbithouse && x - 50 <= x_rabbithouse + 200 && y - 50 >= y_rabbithouse && y - 50 <= y_rabbithouse + 200)
                            {
                                MediaPlayer mediaPlayer = new MediaPlayer();
                                string path = Path.Combine(Environment.CurrentDirectory, "Winning Sound Effect.mp3");
                                mediaPlayer.Open(new Uri("C:\\Users\\DELL\\OneDrive\\Desktop\\Lab 4 - TUIO-20231029\\TUIO11_NET-master\\TUIO11_NET-master\\bin\\Debug\\sound of loss.mp3"));
                                mediaPlayer.Play();
                                if (!messageBoxShownRabbit)
                                {
                                    messageBoxShownRabbit = true;
                                    MessageBox.Show("Error: Wrong unfortunately... If you need to restart, please form a circle with your hand");
                                    c.closeConnection();
                                    System.Windows.Forms.Application.Restart();
                                    Environment.Exit(0);
                                    string text = System.IO.File.ReadAllText("C:\\Users\\DELL\\OneDrive\\Desktop\\Lab 4 - TUIO-20231029\\TUIO11_NET-master\\TUIO11_NET-master\\bin\\Debug\\test.txt");
                                    string[] lines = System.IO.File.ReadAllLines(path);
                                    if (lines.Length > 0)
                                    {
                                        if (lines[lines.Length].ToLower().Contains("right"))
                                        {
                                            string lastLine = lines[lines.Length - 1];
                                            Connect connect = new Connect();
                                            connect.connectToSocket("127.0.0.1", 5009);
                                        }
                                    }

                                }

                            }
                            if (x - 50 >= x_birdhouse && x - 50 <= x_birdhouse + 150 && y - 50 >= y_birdhouse && y - 50 <= y_birdhouse + 150)
                            {
                                MediaPlayer mediaPlayer = new MediaPlayer();
                                string path = Path.Combine(Environment.CurrentDirectory, "Winning Sound Effect.mp3");
                                mediaPlayer.Open(new Uri("C:\\Users\\DELL\\OneDrive\\Desktop\\Lab 4 - TUIO-20231029\\TUIO11_NET-master\\TUIO11_NET-master\\bin\\Debug\\sound of loss.mp3"));
                                mediaPlayer.Play();
                                if (!messageBoxShownBird)
                                {
                                    messageBoxShownBird = true;
                                    MessageBox.Show("Error: Wrong unfortunately... If you need to restart, please form a circle with your hand");
                                    c.closeConnection();
                                    System.Windows.Forms.Application.Restart();
                                    Environment.Exit(0);
                                    string text = System.IO.File.ReadAllText("C:\\Users\\DELL\\OneDrive\\Desktop\\Lab 4 - TUIO-20231029\\TUIO11_NET-master\\TUIO11_NET-master\\bin\\Debug\\test.txt");
                                    string[] lines = System.IO.File.ReadAllLines(path);
                                    if (lines.Length > 0)
                                    {
                                        if (lines[lines.Length].ToLower().Contains("right"))
                                        {
                                            string lastLine = lines[lines.Length - 1];
                                            Connect connect = new Connect();
                                            connect.connectToSocket("127.0.0.1", 5009);
                                        }
                                    }

                                }

                            }
                            if (x - 50 >= x_lionhouse && x - 50 <= x_lionhouse + 150 && y - 50 >= y_lionhouse && y - 50 <= y_lionhouse + 150)
                            {
                                MediaPlayer mediaPlayer = new MediaPlayer();
                                string path = Path.Combine(Environment.CurrentDirectory, "Winning Sound Effect.mp3");
                                mediaPlayer.Open(new Uri("C:\\Users\\DELL\\OneDrive\\Desktop\\Lab 4 - TUIO-20231029\\TUIO11_NET-master\\TUIO11_NET-master\\bin\\Debug\\sound of loss.mp3"));
                                mediaPlayer.Play();
                                if (!messageBoxShownDog)
                                {
                                    messageBoxShownDog = true;
                                    MessageBox.Show("Error: Wrong unfortunately... If you need to restart, please form a circle with your hand");
                                    c.closeConnection();
                                    System.Windows.Forms.Application.Restart();
                                    Environment.Exit(0);
                                    string text = System.IO.File.ReadAllText("C:\\Users\\DELL\\OneDrive\\Desktop\\Lab 4 - TUIO-20231029\\TUIO11_NET-master\\TUIO11_NET-master\\bin\\Debug\\test.txt");
                                    string[] lines = System.IO.File.ReadAllLines(path);
                                    if (lines.Length > 0)
                                    {
                                        if (lines[lines.Length].ToLower().Contains("right"))
                                        {
                                            string lastLine = lines[lines.Length - 1];
                                            Connect connect = new Connect();
                                            connect.connectToSocket("127.0.0.1", 5009);
                                        }
                                    }

                                }

                            }
                        }





                        //g.FillRectangle(objBrush, new Rectangle(ox - size / 2, oy - size / 2, size, size));

                        g.TranslateTransform(ox, oy);
                        g.RotateTransform(-1 * (float)(tobj.Angle / Math.PI * 180.0f));
                        g.TranslateTransform(-ox, -oy);


                        //g.DrawString(tobj.SymbolID + "", font, fntBrush, new PointF(ox - 10, oy - 10));
                    }
                }

            }

            // draw the blobs
            if (blobList.Count > 0)
            {
                lock (blobList)
                {
                    foreach (TuioBlob tblb in blobList.Values)
                    {
                        int bx = tblb.getScreenX(width);
                        int by = tblb.getScreenY(height);
                        float bw = tblb.Width * width;
                        float bh = tblb.Height * height;

                        g.TranslateTransform(bx, by);
                        g.RotateTransform((float)(tblb.Angle / Math.PI * 180.0f));
                        g.TranslateTransform(-bx, -by);

                        g.FillEllipse(blbBrush, bx - bw / 2, by - bh / 2, bw, bh);

                        g.TranslateTransform(bx, by);
                        g.RotateTransform(-1 * (float)(tblb.Angle / Math.PI * 180.0f));
                        g.TranslateTransform(-bx, -by);

                        g.DrawString(tblb.BlobID + "", font, fntBrush, new PointF(bx, by));
                    }
                }
            }
            if (img_lionhouse != null)
            {

                g.DrawImage(img_lionhouse, x_lionhouse, y_lionhouse, 300, 300);
            }

            if (img_monkeyhouse != null)
            {

                g.DrawImage(img_monkeyhouse, x_monkeyhouse, y_monkeyhouse, 300, 300);
            }
            if (img_birdhouse != null)
            {

                g.DrawImage(img_birdhouse, x_birdhouse, y_birdhouse, 300, 300);
            }
            if (img_rabbithouse != null)
            {

                g.DrawImage(img_rabbithouse, x_rabbithouse, y_rabbithouse, 300, 300);
            }
            if (img_doghouse != null)
            {

                g.DrawImage(img_doghouse, x_doghouse, y_doghouse, 300, 300);
            }
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // TuioDemo
            // 
            this.ClientSize = new System.Drawing.Size(1140, 500);
            this.Name = "TuioDemo";
            this.Load += new System.EventHandler(this.TuioDemo_Load_1);
            this.ResumeLayout(false);

        }

        void DrawScene(Graphics g)
        {
            //Bitmap img_cage;
            //if (flag_arrive==1)
            //{

            //g.Clear(Color.White);
            //x_cage = 0;
            //y_cage = 100;
            //img_cage = new Bitmap("lion house2.bmp");
            //img_cage.MakeTransparent(Color.White);
            //img_cage.MakeTransparent(img_cage.GetPixel(0, 0));
            //g.DrawImage(img_cage, x_cage, y_cage, 150, 150);
            //}


        }
        void DrawDubb(Graphics g)
        {
            
            Graphics g2 = Graphics.FromImage(off);
            DrawScene(g2);
            g.DrawImage(off, 0, 0);
        }

        public static void Main(string[] argv)
        {
            int port = 0;
            switch (argv.Length)
            {
                case 1:
                    port = int.Parse(argv[0], null);
                    if (port == 0) goto default;
                    break;
                case 0:
                    port = 3333;
                    break;
                default:
                    Console.WriteLine("usage: mono TuioDemo [port]");
                    Environment.Exit(0);
                    break;
            }

            TuioDemo app = new TuioDemo(port);
            Application.Run(app);
        }
    }
}


